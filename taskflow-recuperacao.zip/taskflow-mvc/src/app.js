require('dotenv').config(); // Carrega o .env logo no início
const express = require('express');
const path = require('path');
const conectarBanco = require('./config/database');
const loggerMiddleware = require('./middlewares/logger');
const tarefaRoutes = require('./routes/tarefaRoutes');

const app = express();
const PORT = process.env.PORT || 3000;

// Middlewares globais
app.use(express.json());              // Parseia o body das requisições como JSON
app.use(express.static(path.join(__dirname, '../public'))); // Serve arquivos estáticos
app.use(loggerMiddleware);            // Loga cada requisição que chega

// Rotas da API
app.use('/api/tarefas', tarefaRoutes);

// Rota raiz — serve o frontend
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, '../public', 'index.html'));
});

// Rota 404 para qualquer endpoint desconhecido
app.use((req, res) => {
  res.status(404).json({ sucesso: false, mensagem: 'Rota não encontrada' });
});

// Conecta no banco e só depois sobe o servidor
conectarBanco().then(() => {
  app.listen(PORT, () => {
    console.log(`🚀 Servidor rodando em http://localhost:${PORT}`);
  });
});
